import Data.Maybe
import qualified Data.Aeson as JSON
import GHC.Generics (Generic)
import Data.Conduit (Conduit)
import qualified Data.Set as S
import qualified Data.Graph.Inductive.Graph as G
import Data.Graph.Inductive.PatriciaTree

import DNIWE.Punt.Interface.Types
import DNIWE.Punt.Interface.Internal
import DNIWE.Punt.Interface.Process
import DNIWE.Punt.Interface.Protocol
import DNIWE.Punt.Solver.Types
import DNIWE.Punt.Solver.Game

main :: IO ()
main = runInternalServer $ internalServer gd gs
  where board = StartingBoard { sbBoard = G.empty, sbMines = S.fromList [] }
        gd = gameData board [] 0 2
        gs = initialState gd