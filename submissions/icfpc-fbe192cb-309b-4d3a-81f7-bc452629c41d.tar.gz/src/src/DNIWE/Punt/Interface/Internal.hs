module DNIWE.Punt.Interface.Internal where

import System.IO
import Control.Applicative
import Control.Monad.Trans.Class (lift)
import GHC.Generics (Generic)
import qualified Data.HashMap.Lazy as HM
import Data.Serialize (Serialize(..))
import qualified Data.Serialize as Cer
import Data.Aeson (ToJSON(..), FromJSON(..), genericParseJSON, genericToJSON, genericToEncoding)
import Data.Aeson.Types (Options(..), SumEncoding(..), defaultOptions)
import Data.Aeson.Casing(snakeCase)
import qualified Data.Aeson as JSON
import Data.Conduit
import qualified Data.Conduit.List as CL
import qualified Data.Conduit.Binary as CB
import Data.Conduit.Attoparsec
import Debug.Trace
import qualified Data.Graph.Inductive.Graph as G

import qualified Data.Map as M

import qualified Data.ByteString.Base64 as Base64
import qualified Data.Text.Encoding as TE

import DNIWE.Punt.Solver.Types
import DNIWE.Punt.Interface.Types
import DNIWE.Punt.Interface.Protocol

jsonOptions' :: Options
jsonOptions' = jsonOptions {
    fieldLabelModifier = dropPrefix . snakeCase
  , sumEncoding = TaggedObject { tagFieldName = "action", contentsFieldName = error "jsonOptions': contentsFieldName" }
}

-- edge
data IEdge = IEdge { eSrc :: SiteId, eDst :: SiteId }
    deriving (Show, Eq, Generic)

instance FromJSON IEdge where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON IEdge where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

-- edge features
data EdgeFeatures = EdgeFeatures { efEdge :: IEdge, efFeatures :: [Double], efValid :: Bool }
    deriving (Show, Eq, Generic)

instance FromJSON EdgeFeatures where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON EdgeFeatures where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

-- edge probabilities
data EdgeProbability = EdgeProbability { epEdge :: IEdge, epProbability :: Double }
    deriving (Show, Eq, Generic)

instance FromJSON EdgeProbability where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON EdgeProbability where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

-- settings
data SettingsRQ = SettingsRQ { sqAction :: String }
    deriving (Show, Eq, Generic)

instance FromJSON SettingsRQ where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON SettingsRQ where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

data SettingsRS = SettingsRS { ssAction :: String, ssFeatureCount :: Int }
    deriving (Show, Eq, Generic)

instance FromJSON SettingsRS where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON SettingsRS where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

-- incidence matrix
data MatrixRQ = MatrixRQ { mqAction :: String }
    deriving (Show, Eq, Generic)

instance FromJSON MatrixRQ where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON MatrixRQ where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

data MatrixRS = MatrixRS { msAction :: String, msValues :: [EdgeFeatures] }
    deriving (Show, Eq, Generic)

instance FromJSON MatrixRS where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON MatrixRS where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

-- probabilities
data ProbabilitiesRQ = ProbabilitiesRQ { pqAction :: String, pqValues :: [EdgeProbability] }
    deriving (Show, Eq, Generic)

instance FromJSON ProbabilitiesRQ where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON ProbabilitiesRQ where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

data ProbabilitiesRS = ProbabilitiesRS { psAction :: String, psReward :: Double }
    deriving (Show, Eq, Generic)

instance FromJSON ProbabilitiesRS where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON ProbabilitiesRS where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

-- claim
data ClaimRQ = ClaimRQ { cqAction :: String, cqEdge :: IEdge }
    deriving (Show, Eq, Generic)

instance FromJSON ClaimRQ where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON ClaimRQ where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

data ClaimRS = ClaimRS { csAction :: String, csReward :: Double }
    deriving (Show, Eq, Generic)

instance FromJSON ClaimRS where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON ClaimRS where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

-- finished
data FinishedRQ = FinishedRQ { fqAction :: String }
    deriving (Show, Eq, Generic)

instance FromJSON FinishedRQ where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON FinishedRQ where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

data FinishedRS = FinishedRS { fsAction :: String, fsFinished :: Bool, fsMessage :: String }
    deriving (Show, Eq, Generic)

instance FromJSON FinishedRS where
  parseJSON = genericParseJSON jsonOptions'

instance ToJSON FinishedRS where
  toJSON = genericToJSON jsonOptions'
  toEncoding = genericToEncoding jsonOptions'

--

data InternalRQ = InternalSettingsRequest SettingsRQ
                | InternalIncidenceMatrixRequest MatrixRQ
                | InternalProbabilitiesRequest ProbabilitiesRQ
                | InternalClaimRequest ClaimRQ
                | InternalFinishedRequest FinishedRQ
                deriving (Show, Eq)

instance FromJSON InternalRQ where
  parseJSON p = (InternalSettingsRequest <$> parseJSON p)
                <|> (InternalIncidenceMatrixRequest <$> parseJSON p)
                <|> (InternalProbabilitiesRequest <$> parseJSON p)
                <|> (InternalClaimRequest <$> parseJSON p)
                <|> (InternalFinishedRequest <$> parseJSON p)

instance ToJSON InternalRQ where
  toJSON (InternalSettingsRequest r) = toJSON r
  toJSON (InternalIncidenceMatrixRequest r) = toJSON r
  toJSON (InternalProbabilitiesRequest r) = toJSON r
  toJSON (InternalClaimRequest r) = toJSON r
  toJSON (InternalFinishedRequest r) = toJSON r

-- impl

actionToString :: InternalRQ -> String
actionToString (InternalSettingsRequest _) = "settings"
actionToString (InternalIncidenceMatrixRequest _) = "incidence_matrix"
actionToString (InternalProbabilitiesRequest _) = "probabilities"
actionToString (InternalClaimRequest _) = "claim"
actionToString (InternalFinishedRequest _) = "finished"

internalServer :: GameData -> GameState -> Conduit JSON.Value IO JSON.Value
internalServer (GameData {..}) (GameState {..}) = do
  lift . putStrLn $ "Starting session"
  let loop = awaitJSON >>= \case
        r@(InternalSettingsRequest sq@(SettingsRQ {..})) -> do
          lift . putStrLn $ "Got " ++ sqAction ++ " query: " ++ show sq
          let dummy = SettingsRS { ssFeatureCount = 10, ssAction = actionToString r }

          lift . putStrLn $ "Answering: " ++ show dummy
          yieldJSON dummy

        r@(InternalIncidenceMatrixRequest mq@(MatrixRQ {..})) -> do
          lift . putStrLn $ "Got " ++ mqAction ++ " query: " ++ show mq
          let ms = MatrixRS { msValues = map (\e@(s,t) -> 
          	                        EdgeFeatures { efEdge = IEdge { eSrc = s, eDst = t }
          	                                     , efFeatures = [1..10]
          	                                     , efValid = M.member e stateTaken
          	                                     }
          	                                 ) $ G.edges $ sbBoard gameStarting
                            , msAction = actionToString r
                            }
          yieldJSON ms

        r@(InternalProbabilitiesRequest pq@(ProbabilitiesRQ {..})) -> do
          lift . putStrLn $ "Got " ++ pqAction ++ " query: " ++ show pq
          
          let probabilities = foldr1 (M.union) $ map (\(EdgeProbability {..}) -> M.singleton (eSrc epEdge, eDst epEdge) epProbability) pqValues
          lift . putStrLn $ "Got some probabilities: " ++ show probabilities ++ ", I'll reward it as 100500!"

          --let updateProbabilities _ = trace "TODO!"
          --updateProbabilities probabilities

          let ps = ProbabilitiesRS { psReward = 100500.0, psAction = actionToString r }
          yieldJSON ps

        r@(InternalClaimRequest cq@(ClaimRQ {..})) -> do
          lift . putStrLn $ "Got " ++ cqAction ++ " query: " ++ show cq
          
          let e = (eSrc cqEdge, eDst cqEdge)
          lift . putStrLn $ "Claiming edge: " ++ show e ++ ", I'll reward it as 100500!"

          --let claim _ = trace "TODO!"
          --claim e

          let cs = ClaimRS { csReward = 100500.0, csAction = actionToString r }
          yieldJSON cs

        r@(InternalFinishedRequest fq@(FinishedRQ {..})) -> do
          lift . putStrLn $ "Got " ++ fqAction ++ " query: " ++ show fq

          let isFinished = trace "TODO!" $ True
          let cs = FinishedRS { fsFinished = isFinished, fsAction = actionToString r }
          if isFinished then
          	do
              lift . putStrLn $ "Finishing client brutally..."
            
              --let finishHim = trace "TODO!"
              --finishHim

              yieldJSON cs { fsMessage = "Go punt yerself, lambdabitch!" }
          else
          	yieldJSON cs
  loop

-- conduit

runInternalServer :: Conduit JSON.Value IO JSON.Value -> IO ()
runInternalServer conduit = do
  CB.sourceHandle stdin $$ conduitParser messageParser =$= CL.map snd =$= conduit =$= CL.map encodeMessage =$= CB.sinkHandle stdout